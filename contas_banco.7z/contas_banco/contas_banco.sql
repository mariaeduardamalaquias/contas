-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Mar-2023 às 21:39
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `contas_banco`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `contaspagar`
--

CREATE TABLE `contaspagar` (
  `codAtrasadas` int(11) NOT NULL,
  `codUsuario` int(11) DEFAULT NULL,
  `codDespesa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `despesas`
--

CREATE TABLE `despesas` (
  `contaLuz` int(11) DEFAULT NULL,
  `contaAgua` int(11) DEFAULT NULL,
  `contaInternet` int(11) DEFAULT NULL,
  `faturaCartao` int(11) DEFAULT NULL,
  `codDespesa` int(11) NOT NULL,
  `codUsuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `extratodesp`
--

CREATE TABLE `extratodesp` (
  `codDespesaExt` int(11) NOT NULL,
  `codUsuario` int(11) DEFAULT NULL,
  `codDespesa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `extratorec`
--

CREATE TABLE `extratorec` (
  `codExtrato` int(11) NOT NULL,
  `numeroConta` int(11) DEFAULT NULL,
  `instituicao` varchar(200) DEFAULT NULL,
  `numeroAgencia` int(5) DEFAULT NULL,
  `tipoConta` varchar(20) DEFAULT NULL,
  `codReceber` int(11) DEFAULT NULL,
  `codUsuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `receber`
--

CREATE TABLE `receber` (
  `salario` int(11) DEFAULT NULL,
  `codReceber` int(11) NOT NULL,
  `codUsuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(100) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `cpf` int(20) DEFAULT NULL,
  `codUsuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `contaspagar`
--
ALTER TABLE `contaspagar`
  ADD PRIMARY KEY (`codAtrasadas`),
  ADD KEY `codUsuario` (`codUsuario`),
  ADD KEY `codDespesa` (`codDespesa`);

--
-- Índices para tabela `despesas`
--
ALTER TABLE `despesas`
  ADD PRIMARY KEY (`codDespesa`),
  ADD KEY `codUsuario` (`codUsuario`);

--
-- Índices para tabela `extratodesp`
--
ALTER TABLE `extratodesp`
  ADD PRIMARY KEY (`codDespesaExt`),
  ADD KEY `codUsuario` (`codUsuario`),
  ADD KEY `codDespesa` (`codDespesa`);

--
-- Índices para tabela `extratorec`
--
ALTER TABLE `extratorec`
  ADD PRIMARY KEY (`codExtrato`),
  ADD KEY `codReceber` (`codReceber`),
  ADD KEY `codUsuario` (`codUsuario`);

--
-- Índices para tabela `receber`
--
ALTER TABLE `receber`
  ADD PRIMARY KEY (`codReceber`),
  ADD KEY `codUsuario` (`codUsuario`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`codUsuario`);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `contaspagar`
--
ALTER TABLE `contaspagar`
  ADD CONSTRAINT `contaspagar_ibfk_1` FOREIGN KEY (`codUsuario`) REFERENCES `usuario` (`codUsuario`),
  ADD CONSTRAINT `contaspagar_ibfk_2` FOREIGN KEY (`codDespesa`) REFERENCES `despesas` (`codDespesa`);

--
-- Limitadores para a tabela `despesas`
--
ALTER TABLE `despesas`
  ADD CONSTRAINT `despesas_ibfk_1` FOREIGN KEY (`codUsuario`) REFERENCES `usuario` (`codUsuario`);

--
-- Limitadores para a tabela `extratodesp`
--
ALTER TABLE `extratodesp`
  ADD CONSTRAINT `extratodesp_ibfk_1` FOREIGN KEY (`codUsuario`) REFERENCES `usuario` (`codUsuario`),
  ADD CONSTRAINT `extratodesp_ibfk_2` FOREIGN KEY (`codDespesa`) REFERENCES `despesas` (`codDespesa`);

--
-- Limitadores para a tabela `extratorec`
--
ALTER TABLE `extratorec`
  ADD CONSTRAINT `extratorec_ibfk_1` FOREIGN KEY (`codReceber`) REFERENCES `receber` (`codReceber`),
  ADD CONSTRAINT `extratorec_ibfk_2` FOREIGN KEY (`codUsuario`) REFERENCES `usuario` (`codUsuario`);

--
-- Limitadores para a tabela `receber`
--
ALTER TABLE `receber`
  ADD CONSTRAINT `receber_ibfk_1` FOREIGN KEY (`codUsuario`) REFERENCES `usuario` (`codUsuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
