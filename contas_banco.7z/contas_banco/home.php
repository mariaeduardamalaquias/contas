<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>C++ Bank</title>
    <link rel="icon" href="imgs/logo.png" >
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<header>
    <div id = "link">
            <a href="home.php">HOME</a>
            <a href="usuario.php">Usúrio</a>
            <a href="extratodesp.php">Extrato D</a>
            <a href="receber.php">Salário</a>
            <a href="contaspagar.php">Dívidas</a>
            <a href="despesas.php">Despesas</a>
            <a href="extratorec.php">Extrato R</a>
    </div>
</header><br>
<br>
<br>
    <div class="banner">
		<img src="imgs/banner.png">
	</div>
<br>
 <div class="plano">
        <center>
            <h1>PLANOS</h1>
        <img src= "imgs/plano1.jpeg" width=300 height= auto padding= 20> 
        <img src= "imgs/plano2.jpg" width=300 height= auto> 
        <img src= "imgs/plano2.jpg" width=300 height= auto>     
</div> 

</body>
</html> 
<!-- Todas realizaram a parte visual desde o HTML e CSS ao Design da empresas, Samara fez o home, Maria Eduarda fez o cabecalho e Mariana inseriu as divs -->