<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>C++ Bank</title>
    <link rel="icon" href="imgs/logo.png" >
    <link rel="stylesheet" href="css/estilo.css">

</head>
<body>
<header>
    <div id = "link">
            <a href="home.php">HOME</a>
            <a href="usuario.php">Usuário</a>
            <a href="extratodesp.php">Extrato D</a>
            <a href="receber.php">Salário</a>
            <a href="contaspagar.php">Dívidas</a>
            <a href="despesas.php">Despesas</a>
            <a href="extratorec.php">Extrato R</a>
            
        </div>
</header><br>
<br>
<br>

    <div class="banner">
		<img src="imgs/banner.png">
	</div>
    <!DOCTYPE html>
<html lang="pt-br">
    <?php

$c = mysqli_connect ("localhost", "root", "", "contas_banco");
if (mysqli_connect_errno()<> 0) {
    $msg = mysqli_connect_error ();
    echo " Erro na conexão SQL!" ."<\br>";
    echo "o MySQL retornou a segunite mensagem:" .$msg."<br>";
} else{
   
    echo "Conexão ok, podemos continuar!". "<br>";
    /* $result = mysqli_query($c, "INSERT INTO despesas (contaLuz, contaAgua, contaInternet, faturaCartao, codDespesa, codUsuario)
                                                VALUES(100, 150, 90, 1800, 300, 410),
                                                      (200, 120,80, 1200, 400, 411),
                                                      (300, 50,70, 2300, 570, 412 );");
    if ($result == true) { ;
        echo "Execução bem sucedida do INSERT!"."<br>";
    } else {
        $msg = mysqli_error ($c);
        echo "Falha no INSERT! Mensagem de erro: " . $msg . "<br>";
    } */

    /* $sql = "UPDATE despesas SET contaLuz= 50 WHERE codDespesa = 300; ";
    $result = mysqli_query ($c, $sql);

    if ($result == true) {
        echo "Alteração ok" . "<br>";
    } else{
        echo "Aleteração não feita". $msg. "<br>";
    }  */

    /* $sql = "DELETE FROM despesas WHERE codDespesa = 300; ";
    $result = mysqli_query ($c, $sql);

    if ($result == true) {
        echo "Exclusão ok" . "<br>";
    } else{
        echo "Exclusão não feita".  $msg . "<br>";
    }  */

/*    $sql= "SELECT * FROM despesas";
    $consulta = mysqli_query ($c, $sql);
    for ($i = 0; $i < mysqli_num_rows($consulta); $i++){
        echo "<br>" . "Resultado do select full de usuario" . "<br>";
        $linha = mysqli_fetch_assoc($consulta);
        echo "<br>" . $linha ['contaLuz'];
    }
 */
   /*  $sql = "SELECT faturaCartao, contaAgua FROM despesas WHERE faturaCartao = 1800";
    $consulta =  mysqli_query ($c, $sql);
    if (mysqli_num_rows ($consulta) <> 0) {
          echo"<br>"."Resultado do Select com chave cpf do usuario"."<br>";
        $linha = mysqli_fetch_assoc($consulta);
        echo "<br>". $linha['faturaCartao'] . "<br>" . $linha['contaAgua'];
    } */

    $sql = "SELECT contaInternet, codDespesa FROM despesas WHERE  contaInternet = 90 and codDespesa = 300";
    $consulta = mysqli_query($c,$sql);
    if (mysqli_num_rows ($consulta) <> 0) {
        echo "<br>" . "Resultado do Select chave dedespesas (contaInternet e codDespesa)" ;
        $linha = mysqli_fetch_assoc ($consulta);
        echo "<br>" . $linha ['contaInternet'] . "<br>" . $linha ['codDespesa'];
    } 
}
?>

</body>
</html>
<!-- Todas realizaram a parte visual, Maria Eduarda fez as despesas -->