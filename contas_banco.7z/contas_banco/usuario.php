<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>C++ Bank</title>
    <link rel="icon" href="imgs/logo.png" >
    <link rel="stylesheet" href="css/estilo.css">

</head>
<body>
<header>
    <div id = "link">
            <a href="home.php">HOME</a>
            <a href="usuario.php">Usuário</a>
            <a href="extratodesp.php">Extrato D</a>
            <a href="receber.php">Salário</a>
            <a href="contaspagar.php">Dívidas</a>
            <a href="despesas.php">Despesas</a>
            <a href="extratorec.php">Extrato R</a>
    </div>
</header><br>
<br>
<br>

    <div class="banner">
		<img src="imgs/banner.png">
	</div>
    <!DOCTYPE html>
<html lang="pt-br">
    
<?php

$c = mysqli_connect ("localhost", "root", "", "contas_banco");
if (mysqli_connect_errno()<> 0) {
    $msg = mysqli_connect_error ();
    echo " Erro na conexão SQL!" ."<\br>";
    echo "o MySQL retornou a segunite mensagem:" .$msg."<br>";
} else{
   
    echo "Conexão ok, podemos continuar!". "<br>";
    $result = mysqli_query($c, "INSERT INTO usuario (nome, data_nascimento, cpf, codUsuario)
                                                    VALUES('samara', 2004/04/01, 30, 410),
                                                     ('Mariana', 2005/05/01, 40, 411),
                                                     ('Maria', 2003/03/10, 57, 412 );");
    if ($result == true) { ;
        echo "Execução bem sucedida do INSERT!"."<br>";
    } else {
        $msg = mysqli_error ($c);
        echo "Falha no INSERT! Mensagem de erro: " . $msg . "<br>";
    }

    /* $sql = "UPDATE usuario SET nome= 'Sol' WHERE CodUsuario = 410; ";
    $result = mysqli_query ($c, $sql);

    if ($result == true) {
        echo "Alteração ok" . "<br>";
    } else{
        echo "Aleteração não feita". $msg . "<br>";
    }  */

    /* $sql = "DELETE FROM usuario WHERE codUsuario = 410; ";
    $result = mysqli_query ($c, $sql);

    if ($result == true) {
        echo "Exclusão ok" . "<br>";
    } else{
        echo "Exclusão não feita".  $msg . "<br>";
    }   */

    /* $sql= "SELECT * FROM usuario";
    $consulta = mysqli_query ($c, $sql);
    for ($i = 0; $i < mysqli_num_rows($consulta); $i++){
        echo "<br>" . "Resultado do select full de usuario" . "<br>";
        $linha = mysqli_fetch_assoc($consulta);
        echo "<br>" . $linha ['cpf'];
    } */

  /*   $sql = "SELECT nome, data_nascimento FROM usuario WHERE cpf = 40";
    $consulta =  mysqli_query ($c, $sql);
    if (mysqli_num_rows ($consulta) <> 0){
        echo"<br>"."Resultado do Select com chave cpf do usuario"."<br>";
        $linha = mysqli_fetch_assoc($consulta);
        echo "<br>". $linha['nome'] . "<br>" . $linha['data_nascimento'];
    } */

      $sql = "SELECT codUsuario, cpf from usuario WHERE codUsuario = 411 and cpf= 40";
    $consulta = mysqli_query($c,$sql);
    if (mysqli_num_rows ($consulta) <> 0) {
        echo "<br>" . "Resultado do Select chave de usuario (codUsuario e cpf)" ;
        $linha = mysqli_fetch_assoc ($consulta);
        echo "<br>" . $linha ['codUsuario'] . "<br>" . $linha ['cpf'];
    }   
}
?>

</body>
</html>
<!-- Todas realizaram a parte visual, Samara fez o Usuario-->